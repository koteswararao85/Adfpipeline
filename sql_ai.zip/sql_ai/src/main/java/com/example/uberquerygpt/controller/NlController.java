package com.example.uberquerygpt.controller;

import com.example.uberquerygpt.service.Nl2SqlService;
import com.example.uberquerygpt.service.LlmNl2SqlService;
import com.example.uberquerygpt.service.OllamaNl2SqlService;
import com.example.uberquerygpt.service.SqlQueryService;
import com.example.uberquerygpt.service.SchemaIntrospectionService;
import com.example.uberquerygpt.service.CustomGatewayNl2SqlService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class NlController {

  private final Nl2SqlService nl2SqlService;
  private final SqlQueryService sqlQueryService;
  private final LlmNl2SqlService llmNl2SqlService;
  private final OllamaNl2SqlService ollamaNl2SqlService;
  private final SchemaIntrospectionService schemaIntrospectionService;
  private final CustomGatewayNl2SqlService customGatewayNl2SqlService;

  public NlController(Nl2SqlService nl2SqlService, SqlQueryService sqlQueryService, LlmNl2SqlService llmNl2SqlService, OllamaNl2SqlService ollamaNl2SqlService, SchemaIntrospectionService schemaIntrospectionService, CustomGatewayNl2SqlService customGatewayNl2SqlService) {
    this.nl2SqlService = nl2SqlService;
    this.sqlQueryService = sqlQueryService;
    this.llmNl2SqlService = llmNl2SqlService;
    this.ollamaNl2SqlService = ollamaNl2SqlService;
    this.schemaIntrospectionService = schemaIntrospectionService;
    this.customGatewayNl2SqlService = customGatewayNl2SqlService;
  }

  @GetMapping("/nl")
  public String nlPage(Model model) {
    model.addAttribute("text", "list all articles");
    return "nl";
  }

  @PostMapping(value = "/api/nlsql", consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Map<String, Object>> runNl(@RequestBody String text, @org.springframework.web.bind.annotation.RequestParam(value = "use", required = false) String use, @org.springframework.web.bind.annotation.RequestParam(value = "table", required = false) String table) {
    String trimmed = text == null ? "" : text.trim();
    // If the user typed a raw SQL SELECT, execute directly instead of NL->SQL
    if (!trimmed.isEmpty() && trimmed.toLowerCase().startsWith("select")) {
      try {
        Map<String, Object> out = new HashMap<>();
        out.put("sql", trimmed);
        out.put("result", sqlQueryService.runSelect(trimmed));
        return ResponseEntity.ok(out);
      } catch (Exception ex) {
        Map<String, Object> out = new HashMap<>();
        out.put("sql", trimmed);
        out.put("error", ex.getMessage());
        return ResponseEntity.ok(out);
      }
    }

    String sql;
    String schema = schemaIntrospectionService.buildSchemaDescription();
    if (use != null && use.equalsIgnoreCase("llm")) {
      try {
        sql = llmNl2SqlService.toSql(text, schema, table);
      } catch (Exception e) {
        // fallback to rules
        sql = nl2SqlService.toSql(text, table == null ? "articles" : table);
      }
    } else if (use != null && use.equalsIgnoreCase("ollama")) {
      try {
        sql = ollamaNl2SqlService.toSql(text, schema, table);
      } catch (Exception e) {
        sql = nl2SqlService.toSql(text, table == null ? "articles" : table);
      }
    } else if (use != null && use.equalsIgnoreCase("custom")) {
      try {
        sql = customGatewayNl2SqlService.toSql(text, schema, table);
      } catch (Exception e) {
        sql = nl2SqlService.toSql(text, table == null ? "articles" : table);
      }
    } else {
      sql = nl2SqlService.toSql(text, table == null ? "articles" : table);
    }
    System.out.println("koti====" + sql);
    try {
      Map<String, Object> out = new HashMap<>();
      out.put("sql", sql);
      out.put("result", sqlQueryService.runSelect(sql));
      return ResponseEntity.ok(out);
    } catch (Exception ex) {
      // attempt one repair with provider if used
      try {
        String repaired = null;
        if (use != null && use.equalsIgnoreCase("llm")) {
          repaired = llmNl2SqlService.reviseSql(text, schema, sql, ex.getMessage(), table);
        } else if (use != null && use.equalsIgnoreCase("ollama")) {
          repaired = ollamaNl2SqlService.reviseSql(text, schema, sql, ex.getMessage());
        }
        if (repaired != null) {
          Map<String, Object> out = new HashMap<>();
          out.put("sql", repaired);
          out.put("result", sqlQueryService.runSelect(repaired));
          return ResponseEntity.ok(out);
        }
      } catch (Exception ignore) {
        // fall through
      }
      // final fallback: return error
      Map<String, Object> out = new HashMap<>();
      out.put("sql", sql);
      out.put("error", ex.getMessage());
      return ResponseEntity.ok(out);
    }
  }
}


