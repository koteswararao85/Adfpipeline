package com.example.uberquerygpt.service;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.stereotype.Service;

@Service
public class Nl2SqlService {

  private static final Pattern GREATER_THAN_ID = Pattern.compile("id\\s*(?:greater than|>|above)\\s*(\\d+)");
  private static final Pattern ID_EQUALS = Pattern.compile("id\\s*(?:=|equals|is)\\s*(\\d+)");

  public String toSql(String naturalLanguage) {
    return toSql(naturalLanguage, "articles");
  }

  public String toSql(String naturalLanguage, String tableName) {
    String table = sanitizeIdentifier(tableName);
    if (naturalLanguage == null || naturalLanguage.isBlank()) {
      return "select * from " + table;
    }
    String nl = naturalLanguage.trim().toLowerCase(Locale.ROOT);

    // Group-by Title with Count
    if (isCountByTitle(nl)) {
      return "select title, count(*) as count from " + table + " group by title order by count desc";
    }

    // Aggregations: max/min for id
    String maxCol = detectMaxColumn(nl);
    if (maxCol != null) {
      return "select max(" + maxCol + ") as max_" + maxCol + " from " + table;
    }
    String minCol = detectMinColumn(nl);
    if (minCol != null) {
      return "select min(" + minCol + ") as min_" + minCol + " from " + table;
    }

    // Basic intents
    if (nl.contains("count")) {
      return "select count(*) as count from " + table;
    }
    if (nl.contains("titles") || nl.contains("title")) {
      String base = "select id, title from " + table;
      String filtered = applyTitleFilters(nl, base);
      return applyIdFilters(nl, filtered);
    }
    // Department-specific intents
    String deptValue = detectDepartmentFilterValue(nl);
    if (deptValue != null) {
      String val = escapeLikeLiteral(deptValue);
      return "select * from " + table + " where lower(department) like '%" + val + "%'";
    }
    if ((nl.contains("list") || nl.contains("show")) && (nl.contains("dept") || nl.contains("department"))) {
      return "select distinct department from " + table + " order by department";
    }

    if (nl.contains("list") || nl.contains("show") || nl.contains("all") || nl.contains("articles")) {
      String base = "select * from " + table;
      String filtered = applyTitleFilters(nl, base);
      return applyIdFilters(nl, filtered);
    }

    // Default fallback
    return "select * from " + table;
  }

  private boolean isCountByTitle(String nl) {
    // Matches phrases like:
    //  - group by title with count
    //  - count by title
    //  - number of articles per title
    //  - titles grouped with counts
    boolean mentionsTitle = nl.contains("title") || nl.contains("titles");
    boolean mentionsGroup = nl.contains("group by") || nl.contains("grouped by") || nl.contains("grouped") || nl.contains("per title") || nl.contains("by title");
    boolean mentionsCount = nl.contains("count") || nl.contains("number");
    return mentionsTitle && mentionsCount && mentionsGroup;
  }

  private String detectMaxColumn(String nl) {
    // Patterns: "max id", "maximum id", "highest id", "largest id", "greatest id",
    //           "max of id", "what is the max id", etc.
    Pattern p = Pattern.compile("(?:max(?:imum)?|highest|largest|greatest)\\s+(?:value\\s+of\\s+)?([a-zA-Z_][a-zA-Z0-9_]*)");
    Matcher m = p.matcher(nl);
    if (m.find()) {
      String col = m.group(1);
      if ("id".equals(col)) {
        return "id";
      }
    }
    // Fallback heuristic: mentions max and id anywhere
    if ((nl.contains("max") || nl.contains("maximum") || nl.contains("highest") || nl.contains("largest") || nl.contains("greatest")) && nl.contains("id")) {
      return "id";
    }
    return null;
  }

  private String detectMinColumn(String nl) {
    Pattern p = Pattern.compile("(?:min(?:imum)?|lowest|smallest|least)\\s+(?:value\\s+of\\s+)?([a-zA-Z_][a-zA-Z0-9_]*)");
    Matcher m = p.matcher(nl);
    if (m.find()) {
      String col = m.group(1);
      if ("id".equals(col)) {
        return "id";
      }
    }
    if ((nl.contains("min") || nl.contains("minimum") || nl.contains("lowest") || nl.contains("smallest") || nl.contains("least")) && nl.contains("id")) {
      return "id";
    }
    return null;
  }

  private String applyTitleFilters(String nl, String base) {
    // Look for keywords like query, gpt, analytics, etc. and build a LIKE filter
    StringBuilder where = new StringBuilder();
    if (nl.contains("query")) {
      appendLike(where, "query");
    }
    if (nl.contains("gpt")) {
      appendLike(where, "gpt");
    }
    if (nl.contains("analytics")) {
      appendLike(where, "analytics");
    }
    if (where.length() > 0) {
      return base + " where " + where + " order by id";
    }
    return base + " order by id";
  }

  private String applyIdFilters(String nl, String sql) {
    Matcher m1 = GREATER_THAN_ID.matcher(nl);
    if (m1.find()) {
      int n = Integer.parseInt(m1.group(1));
      return injectWhere(sql, "id > " + n);
    }
    Matcher m2 = ID_EQUALS.matcher(nl);
    if (m2.find()) {
      int n = Integer.parseInt(m2.group(1));
      return injectWhere(sql, "id = " + n);
    }
    return sql;
  }

  private void appendLike(StringBuilder where, String keyword) {
    if (where.length() > 0) {
      where.append(" and ");
    }
    // H2 compatibility: use lower(title) like '%keyword%'
    where.append("lower(title) like '%").append(keyword.toLowerCase(Locale.ROOT)).append("%'");
  }

  private String injectWhere(String sql, String clause) {
    String lower = sql.toLowerCase(Locale.ROOT);
    if (lower.contains(" where ")) {
      return sql.replaceFirst("(?i)order\\s+by", "and " + clause + " order by");
    }
    if (lower.contains(" order by ")) {
      return sql.replaceFirst("(?i)order\\s+by", "where " + clause + " order by");
    }
    return sql + " where " + clause;
  }

  private String detectDepartmentFilterValue(String nl) {
    if (!(nl.contains("department") || nl.contains("dept"))) {
      return null;
    }
    // Try quoted value first: department ... 'sales' or "sales"
    java.util.regex.Matcher mQuoted = java.util.regex.Pattern
        .compile("(?:department|dept)[^\\n]*?(?:name)?[^\\n]*?(?:=|equals|is|with|containing|contains|like)\\s*['\"]([^'\"]+)['\"]")
        .matcher(nl);
    if (mQuoted.find()) {
      return mQuoted.group(1).trim();
    }
    // Unquoted single word after operator
    java.util.regex.Matcher mWord = java.util.regex.Pattern
        .compile("(?:department|dept)[^\\n]*?(?:name)?[^\\n]*?(?:=|equals|is|with|containing|contains|like)\\s+([a-z0-9_\u00C0-\u017F-]+)")
        .matcher(nl);
    if (mWord.find()) {
      return mWord.group(1).trim();
    }
    // Heuristic: look for common department tokens
    if (nl.contains("sales")) return "sales";
    if (nl.contains("engineering")) return "engineering";
    if (nl.contains("support")) return "support";
    if (nl.contains("marketing")) return "marketing";
    return null;
  }

  private String escapeLikeLiteral(String s) {
    if (s == null) return "";
    return s.replace("'", "''");
  }

  private String sanitizeIdentifier(String raw) {
    if (raw == null || raw.isBlank()) {
      return "articles";
    }
    String s = raw.trim().replaceAll("[^A-Za-z0-9_]", "_");
    if (Character.isDigit(s.charAt(0))) {
      s = "t_" + s;
    }
    return s;
  }
}


