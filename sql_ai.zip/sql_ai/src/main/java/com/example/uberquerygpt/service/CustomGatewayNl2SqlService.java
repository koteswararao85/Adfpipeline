package com.example.uberquerygpt.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

@Service
public class CustomGatewayNl2SqlService {

  @Value("${custom.auth.url:https://api.testvalidate.com/oauth2/token}")
  private String authUrl;

  @Value("${custom.auth.scope:https://api.testvalidate.com/.default}")
  private String scope;

  @Value("${custom.auth.clientId:}")
  private String clientId;

  @Value("${custom.auth.clientSecret:}")
  private String clientSecret;

  @Value("${custom.gateway.url:https://api.testvalidate.com/api/cloud/api-management/ai-gateway/1.0/openai/deployments/gpt-4.1_2025-04-14/chat/completions?api-version=2025-04-01-preview}")
  private String gatewayUrl;

  @Value("${custom.gateway.projectId:}")
  private String projectId;

  private final ObjectMapper objectMapper = new ObjectMapper();

  public String toSql(String naturalLanguage, String schemaDescription, String preferredTable) {
    String token = getAccessToken();

    String systemPrompt = "You are a helpful assistant that writes SQL queries. Use the provided schema. Only output a single ANSI SQL SELECT. No DDL/DML.";

    StringBuilder userPrompt = new StringBuilder();
    userPrompt.append("Schema:\n").append(schemaDescription).append("\n\n");
    if (StringUtils.hasText(preferredTable)) {
      userPrompt.append("Preferred table: ").append(preferredTable.trim()).append("\n\n");
    }
    userPrompt.append("Request: ").append(naturalLanguage == null ? "" : naturalLanguage.trim());

    try {
      RestTemplate client = new RestTemplate();
      SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
      factory.setConnectTimeout(20000);
      factory.setReadTimeout(60000);
      client.setRequestFactory(factory);

      Map<String, Object> body = new HashMap<>();
      List<Map<String, String>> messages = new ArrayList<>();
      messages.add(Map.of("role", "system", "content", systemPrompt));
      messages.add(Map.of("role", "user", "content", userPrompt.toString()));
      body.put("messages", messages);
      body.put("max_tokens", 150);
      body.put("temperature", 0.0);
      body.put("top_p", 1.0);
      body.put("model", "gpt-4.1");

      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.set("Authorization", "Bearer " + token);
      if (StringUtils.hasText(projectId)) {
        headers.set("projectId", projectId);
      }

      HttpEntity<String> entity = new HttpEntity<>(objectMapper.writeValueAsString(body), headers);
      ResponseEntity<String> resp = client.exchange(URI.create(gatewayUrl), HttpMethod.POST, entity, String.class);
      if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) {
        throw new RuntimeException("Gateway API error: " + resp.getStatusCode());
      }
      JsonNode root = objectMapper.readTree(resp.getBody());
      String content = root.path("choices").get(0).path("message").path("content").asText("");
      String sql = extractSql(content);
      if (!StringUtils.hasText(sql)) {
        throw new RuntimeException("Empty SQL from custom provider");
      }
      return sql.trim();
    } catch (Exception e) {
      throw new RuntimeException("Custom provider call failed: " + e.getMessage(), e);
    }
  }

  private String getAccessToken() {
    RestTemplate client = new RestTemplate();
    SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
    factory.setConnectTimeout(20000);
    factory.setReadTimeout(60000);
    client.setRequestFactory(factory);

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

    MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
    form.add("grant_type", "client_credentials");
    form.add("scope", scope);
    form.add("client_id", clientId);
    form.add("client_secret", clientSecret);

    HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(form, headers);
    ResponseEntity<String> resp = client.exchange(URI.create(authUrl), HttpMethod.POST, entity, String.class);
    if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) {
      throw new RuntimeException("Auth error: " + resp.getStatusCode());
    }
    try {
      JsonNode root = objectMapper.readTree(resp.getBody());
      String token = root.path("access_token").asText("");
      if (!StringUtils.hasText(token)) {
        throw new RuntimeException("No access_token in response");
      }
      return token;
    } catch (Exception e) {
      throw new RuntimeException("Invalid auth response: " + e.getMessage(), e);
    }
  }

  private String extractSql(String content) {
    if (content == null) return "";
    String trimmed = content.trim();
    int start = trimmed.indexOf("```");
    if (start >= 0) {
      int end = trimmed.indexOf("```", start + 3);
      if (end > start) {
        String inside = trimmed.substring(start + 3, end).trim();
        int nl = inside.indexOf('\n');
        if (nl > 0 && inside.substring(0, nl).toLowerCase().contains("sql")) {
          return inside.substring(nl + 1).trim();
        }
        return inside;
      }
    }
    return trimmed;
  }
}


