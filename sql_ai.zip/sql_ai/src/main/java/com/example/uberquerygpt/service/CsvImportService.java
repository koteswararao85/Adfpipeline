package com.example.uberquerygpt.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class CsvImportService {

  private final JdbcTemplate jdbcTemplate;

  public CsvImportService(JdbcTemplate jdbcTemplate) {
    this.jdbcTemplate = jdbcTemplate;
  }

  public int importCsv(String tableName, InputStream csvInputStream, boolean header) {
    if (!StringUtils.hasText(tableName)) {
      throw new IllegalArgumentException("tableName is required");
    }

    try (BufferedReader reader = new BufferedReader(new InputStreamReader(csvInputStream, StandardCharsets.UTF_8));
         CSVParser parser = header
             ? CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).build().parse(reader)
             : CSVFormat.DEFAULT.parse(reader)) {

      List<String> columnNames = new ArrayList<>();
      List<List<String>> records = new ArrayList<>();

      if (header) {
        columnNames.addAll(parser.getHeaderNames().stream().map(this::stripBom).toList());
      }

      for (CSVRecord record : parser) {
        List<String> row = new ArrayList<>();
        int size = record.size();
        for (int i = 0; i < size; i++) {
          row.add(record.get(i));
        }
        records.add(row);
        if (!header && columnNames.isEmpty()) {
          for (int i = 0; i < size; i++) {
            columnNames.add("c" + (i + 1));
          }
        }
      }

      // Fallback: handle CSVs where entire line is quoted as a single field containing commas
      if (header && columnNames.size() == 1 && columnNames.get(0).contains(",")) {
        columnNames = splitAndUnquote(columnNames.get(0)).stream().map(this::stripBom).toList();
        List<List<String>> normalized = new ArrayList<>(records.size());
        for (List<String> r : records) {
          if (r.size() == 1) {
            normalized.add(splitAndUnquote(r.get(0)));
          } else {
            normalized.add(unquoteRow(r));
          }
        }
        records = normalized;
      } else if (!header && !records.isEmpty() && records.get(0).size() == 1 && records.get(0).get(0) != null && records.get(0).get(0).contains(",")) {
        // No header case with single-field rows that contain commas
        int cols = 0;
        List<List<String>> normalized = new ArrayList<>(records.size());
        for (List<String> r : records) {
          List<String> split = splitAndUnquote(r.get(0));
          cols = Math.max(cols, split.size());
          normalized.add(split);
        }
        if (cols > 0) {
          columnNames.clear();
          for (int i = 0; i < cols; i++) {
            columnNames.add("c" + (i + 1));
          }
          records = normalized;
        }
      } else {
        // Normal case: just unquote individual cells if they are quoted
        List<List<String>> normalized = new ArrayList<>(records.size());
        for (List<String> r : records) {
          normalized.add(unquoteRow(r));
        }
        records = normalized;
      }

      if (columnNames.isEmpty()) {
        throw new IllegalArgumentException("CSV appears to be empty");
      }

      // Create table with all VARCHAR columns for simplicity
      String createColumns = columnNames.stream()
          .map(c -> sanitizeIdentifier(c) + " VARCHAR(255)")
          .collect(Collectors.joining(", "));
      String ddl = "CREATE TABLE IF NOT EXISTS " + sanitizeIdentifier(tableName) + " (" + createColumns + ")";
      jdbcTemplate.execute(ddl);

      // Insert rows
      String placeholders = columnNames.stream().map(c -> "?").collect(Collectors.joining(", "));
      String insertSql = "INSERT INTO " + sanitizeIdentifier(tableName) + " (" +
          columnNames.stream().map(this::sanitizeIdentifier).collect(Collectors.joining(", ")) + ") VALUES (" + placeholders + ")";

      int total = 0;
      for (List<String> row : records) {
        // Pad or trim to match column count
        List<Object> params = new ArrayList<>(columnNames.size());
        for (int i = 0; i < columnNames.size(); i++) {
          params.add(i < row.size() ? row.get(i) : null);
        }
        total += jdbcTemplate.update(insertSql, params.toArray());
      }
      return total;
    } catch (Exception e) {
      throw new RuntimeException("Failed to import CSV: " + e.getMessage(), e);
    }
  }

  private String sanitizeIdentifier(String raw) {
    String s = stripBom(raw).trim().replaceAll("[^A-Za-z0-9_]", "_");
    if (!StringUtils.hasText(s)) {
      s = "col";
    }
    // avoid leading digits
    if (Character.isDigit(s.charAt(0))) {
      s = "c_" + s;
    }
    return s;
  }

  private String stripBom(String s) {
    if (s == null || s.isEmpty()) return s;
    // Remove leading UTF-8 BOM (\uFEFF) if present
    if (s.charAt(0) == '\uFEFF') {
      return s.substring(1);
    }
    return s;
  }

  private List<String> splitAndUnquote(String value) {
    String v = value == null ? "" : value.trim();
    if (v.length() >= 2 && v.startsWith("\"") && v.endsWith("\"")) {
      v = v.substring(1, v.length() - 1);
    }
    String[] parts = v.split(",", -1);
    List<String> out = new ArrayList<>(parts.length);
    for (String p : parts) {
      String s = p.trim();
      if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
        s = s.substring(1, s.length() - 1);
      }
      out.add(s);
    }
    return out;
  }

  private List<String> unquoteRow(List<String> row) {
    List<String> out = new ArrayList<>(row.size());
    for (String v : row) {
      String s = v == null ? null : v.trim();
      if (s != null && s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
        s = s.substring(1, s.length() - 1);
      }
      out.add(s);
    }
    return out;
  }
}


