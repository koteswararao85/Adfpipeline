package com.example.uberquerygpt.controller;

import com.example.uberquerygpt.service.CsvImportService;
import com.example.uberquerygpt.service.SqlQueryService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping
public class SqlController {

  private final SqlQueryService sqlQueryService;
  private final CsvImportService csvImportService;

  public SqlController(SqlQueryService sqlQueryService, CsvImportService csvImportService) {
    this.sqlQueryService = sqlQueryService;
    this.csvImportService = csvImportService;
  }

  @GetMapping("/query")
  public String queryPage(@RequestParam(value = "sql", required = false) String sql, Model model) {
    model.addAttribute("sql", sql == null ? "select * from articles" : sql);
    model.addAttribute("result", null);
    return "query";
  }

  @PostMapping(value = "/api/sql", consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Map<String, Object>> runSql(@RequestBody String sql) {
    return ResponseEntity.ok(sqlQueryService.runSelect(sql));
  }

  @PostMapping(value = "/api/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Map<String, Object>> uploadCsv(
      @RequestParam("file") MultipartFile file,
      @RequestParam("table") String table,
      @RequestParam(value = "header", defaultValue = "true") boolean header) {
    try {
      int inserted = csvImportService.importCsv(table, file.getInputStream(), header);
      Map<String, Object> out = new HashMap<>();
      out.put("table", table);
      out.put("inserted", inserted);
      return ResponseEntity.ok(out);
    } catch (Exception e) {
      Map<String, Object> out = new HashMap<>();
      out.put("error", e.getMessage());
      return ResponseEntity.badRequest().body(out);
    }
  }
}



