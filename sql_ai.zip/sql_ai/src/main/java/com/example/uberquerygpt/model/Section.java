package com.example.uberquerygpt.model;

public class Section {
  private String tag;
  private String text;
  private int orderIndex;

  public Section() {
  }

  public Section(String tag, String text, int orderIndex) {
    this.tag = tag;
    this.text = text;
    this.orderIndex = orderIndex;
  }

  public String getTag() {
    return tag;
  }

  public void setTag(String tag) {
    this.tag = tag;
  }

  public String getText() {
    return text;
  }

  public void setText(String text) {
    this.text = text;
  }

  public int getOrderIndex() {
    return orderIndex;
  }

  public void setOrderIndex(int orderIndex) {
    this.orderIndex = orderIndex;
  }
}



