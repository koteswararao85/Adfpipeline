package com.example.uberquerygpt.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

@Service
public class LlmNl2SqlService {

  @Value("${openai.apiKey:}")
  private String apiKey;

  @Value("${openai.model:gpt-4o-mini}")
  private String model;

  @Value("${openai.baseUrl:https://api.openai.com/v1}")
  private String baseUrl;

  private final ObjectMapper objectMapper = new ObjectMapper();

  public String toSql(String naturalLanguage, String schemaDescription) {
    return toSql(naturalLanguage, schemaDescription, null);
  }

  public String toSql(String naturalLanguage, String schemaDescription, String preferredTable) {
    if (!StringUtils.hasText(apiKey)) {
      throw new IllegalStateException("OpenAI API key is not configured");
    }

    String systemPrompt = "You are a SQL translator. Convert user requests into a single ANSI SQL SELECT query. " +
        "Use the provided schema. Avoid DDL/DML. Output ONLY the SQL with no commentary.";

    StringBuilder userPrompt = new StringBuilder();
    userPrompt.append("Schema:\n").append(schemaDescription).append("\n\n");
    if (StringUtils.hasText(preferredTable)) {
      userPrompt.append("Preferred table: ")
          .append(preferredTable.trim())
          .append("\n\n");
    }
    userPrompt.append("Request: ")
        .append(naturalLanguage == null ? "" : naturalLanguage.trim())
        .append("\nReturn ONLY the SQL.");

    try {
      RestTemplate client = new RestTemplate();
      SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
      factory.setConnectTimeout(20000);
      factory.setReadTimeout(60000);
      client.setRequestFactory(factory);

      Map<String, Object> body = new HashMap<>();
      body.put("model", model);
      body.put("temperature", 0);
      body.put("messages", buildFewShotMessages(systemPrompt, userPrompt.toString()));

      String url = baseUrl.endsWith("/") ? baseUrl + "chat/completions" : baseUrl + "/chat/completions";
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.setBearerAuth(apiKey);

      HttpEntity<String> entity = new HttpEntity<>(objectMapper.writeValueAsString(body), headers);
      ResponseEntity<String> resp = client.exchange(URI.create(url), HttpMethod.POST, entity, String.class);
      if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) {
        throw new RuntimeException("OpenAI API error: " + resp.getStatusCode());
      }

      JsonNode root = objectMapper.readTree(resp.getBody());
      JsonNode choices = root.path("choices");
      if (!choices.isArray() || choices.isEmpty()) {
        throw new RuntimeException("No choices returned from OpenAI");
      }
      String content = choices.get(0).path("message").path("content").asText("");
      String sql = extractSql(content);
      if (!StringUtils.hasText(sql)) {
        throw new RuntimeException("Empty SQL from model");
      }
      return sql.trim();
    } catch (Exception e) {
      throw new RuntimeException("Failed to call OpenAI: " + e.getMessage(), e);
    }
  }

  private String extractSql(String content) {
    if (content == null) return "";
    String trimmed = content.trim();
    // If model used code fences
    int start = trimmed.indexOf("```");
    if (start >= 0) {
      int end = trimmed.indexOf("```", start + 3);
      if (end > start) {
        String inside = trimmed.substring(start + 3, end).trim();
        // Remove optional language tag like ```sql
        int nl = inside.indexOf('\n');
        if (nl > 0 && inside.substring(0, nl).toLowerCase().contains("sql")) {
          return inside.substring(nl + 1).trim();
        }
        return inside;
      }
    }
    return trimmed;
  }

  public String reviseSql(String naturalLanguage, String schemaDescription, String previousSql, String errorText) {
    return reviseSql(naturalLanguage, schemaDescription, previousSql, errorText, null);
  }

  public String reviseSql(String naturalLanguage, String schemaDescription, String previousSql, String errorText, String preferredTable) {
    if (!StringUtils.hasText(apiKey)) {
      throw new IllegalStateException("OpenAI API key is not configured");
    }

    String systemPrompt = "You are a SQL repair assistant. Given schema, a user request, a failing SQL and the error message, " +
        "produce a corrected ANSI SQL SELECT query. Output ONLY the SQL. No commentary.";
    StringBuilder userPrompt = new StringBuilder();
    userPrompt.append("Schema:\n").append(schemaDescription).append("\n\n");
    if (StringUtils.hasText(preferredTable)) {
      userPrompt.append("Preferred table: ")
          .append(preferredTable.trim())
          .append("\n\n");
    }
    userPrompt.append("Request:\n")
        .append(naturalLanguage == null ? "" : naturalLanguage.trim())
        .append("\n\nPrevious SQL (failed):\n")
        .append(previousSql == null ? "" : previousSql)
        .append("\n\nError:\n")
        .append(errorText == null ? "" : errorText)
        .append("\n\nReturn ONLY the corrected SQL.");

    try {
      RestTemplate client = new RestTemplate();
      SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
      factory.setConnectTimeout(20000);
      factory.setReadTimeout(60000);
      client.setRequestFactory(factory);

      Map<String, Object> body = new HashMap<>();
      body.put("model", model);
      body.put("temperature", 0);
      body.put("messages", buildFewShotMessages(systemPrompt, userPrompt.toString()));

      String url = baseUrl.endsWith("/") ? baseUrl + "chat/completions" : baseUrl + "/chat/completions";
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.setBearerAuth(apiKey);

      HttpEntity<String> entity = new HttpEntity<>(objectMapper.writeValueAsString(body), headers);
      ResponseEntity<String> resp = client.exchange(URI.create(url), HttpMethod.POST, entity, String.class);
      if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) {
        throw new RuntimeException("OpenAI API error: " + resp.getStatusCode());
      }
      JsonNode root = objectMapper.readTree(resp.getBody());
      JsonNode choices = root.path("choices");
      if (!choices.isArray() || choices.isEmpty()) {
        throw new RuntimeException("No choices returned from OpenAI");
      }
      String content = choices.get(0).path("message").path("content").asText("");
      String sql = extractSql(content);
      if (!StringUtils.hasText(sql)) {
        throw new RuntimeException("Empty SQL from model");
      }
      return sql.trim();
    } catch (Exception e) {
      throw new RuntimeException("Failed to call OpenAI: " + e.getMessage(), e);
    }
  }

  private List<Map<String, String>> buildFewShotMessages(String systemPrompt, String userPrompt) {
    // Few-shot to teach GROUP BY and JOIN patterns without hardcoding table names
    List<Map<String, String>> messages = new java.util.ArrayList<>();
    messages.add(Map.of("role", "system", "content", systemPrompt));

    // Example 1: group by with count
    messages.add(Map.of("role", "user", "content", "Schema:\n table articles(id int, title varchar)\n\nRequest: list all articles group by title with count\nReturn ONLY the SQL."));
    messages.add(Map.of("role", "assistant", "content", "SELECT title, COUNT(*) AS count FROM articles GROUP BY title ORDER BY count DESC"));

    // Example 2: simple join
    messages.add(Map.of("role", "user", "content", "Schema:\n table orders(id int, customer_id int, total decimal),\n table customers(id int, name varchar)\n\nRequest: list orders with customer names\nReturn ONLY the SQL."));
    messages.add(Map.of("role", "assistant", "content", "SELECT o.id, c.name, o.total FROM orders o JOIN customers c ON o.customer_id = c.id"));

    // Real user prompt last
    messages.add(Map.of("role", "user", "content", userPrompt));
    return messages;
  }
}


