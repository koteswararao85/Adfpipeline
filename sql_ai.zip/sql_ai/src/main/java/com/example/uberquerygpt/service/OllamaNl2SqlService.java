package com.example.uberquerygpt.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

@Service
public class OllamaNl2SqlService {

  @Value("${ollama.baseUrl:http://localhost:11434}")
  private String baseUrl;

  @Value("${ollama.model:sqlcoder}")
  private String model;

  private final ObjectMapper objectMapper = new ObjectMapper();

  public String toSql(String naturalLanguage, String schemaDescription) {
    return toSql(naturalLanguage, schemaDescription, null);
  }

  public String toSql(String naturalLanguage, String schemaDescription, String preferredTable) {
    if (!StringUtils.hasText(baseUrl)) {
      throw new IllegalStateException("Ollama baseUrl not configured");
    }

    String systemPrompt = "You are a SQL translator. Convert the user request into a single ANSI SQL SELECT query. " +
        "Only output the SQL, no commentary. Use the provided schema. Avoid DDL/DML; only SELECT.";

    StringBuilder userPrompt = new StringBuilder();
    userPrompt.append("Schema:\n").append(schemaDescription).append("\n\n");
    if (StringUtils.hasText(preferredTable)) {
      userPrompt.append("Preferred table: ")
          .append(preferredTable.trim())
          .append("\n\n");
    }
    userPrompt.append("Request: ")
        .append(naturalLanguage == null ? "" : naturalLanguage.trim())
        .append("\nReturn ONLY the SQL.");

    try {
      RestTemplate client = new RestTemplate();
      SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
      factory.setConnectTimeout(20000);
      factory.setReadTimeout(120000);
      client.setRequestFactory(factory);

      Map<String, Object> body = new HashMap<>();
      body.put("model", model);
      body.put("stream", false);
      body.put("messages", buildFewShotMessages(systemPrompt, userPrompt.toString()));

      String url = baseUrl.endsWith("/") ? baseUrl + "api/chat" : baseUrl + "/api/chat";
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);

      HttpEntity<String> entity = new HttpEntity<>(objectMapper.writeValueAsString(body), headers);
      ResponseEntity<String> resp = client.exchange(URI.create(url), HttpMethod.POST, entity, String.class);
      if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) {
        throw new RuntimeException("Ollama API error: " + resp.getStatusCode());
      }

      JsonNode root = objectMapper.readTree(resp.getBody());
      // Ollama chat response: { message: { content: "..." }, done: true, ... }
      String content = root.path("message").path("content").asText("");
      String sql = extractSql(content);
      if (!StringUtils.hasText(sql)) {
        throw new RuntimeException("Empty SQL from Ollama model");
      }
      return sql.trim();
    } catch (Exception e) {
      throw new RuntimeException("Failed to call Ollama: " + e.getMessage(), e);
    }
  }

  private String extractSql(String content) {
    if (content == null) return "";
    String trimmed = content.trim();
    int fence = trimmed.indexOf("```");
    if (fence >= 0) {
      int end = trimmed.indexOf("```", fence + 3);
      if (end > fence) {
        String inside = trimmed.substring(fence + 3, end).trim();
        int nl = inside.indexOf('\n');
        if (nl > 0 && inside.substring(0, nl).toLowerCase().contains("sql")) {
          return inside.substring(nl + 1).trim();
        }
        return inside;
      }
    }
    return trimmed;
  }

  public String reviseSql(String naturalLanguage, String schemaDescription, String previousSql, String errorText) {
    if (!StringUtils.hasText(baseUrl)) {
      throw new IllegalStateException("Ollama baseUrl not configured");
    }
    String systemPrompt = "You are a SQL repair assistant. Given schema, a user request, a failing SQL and the error message, " +
        "produce a corrected ANSI SQL SELECT query. Output ONLY the SQL.";
    String userPrompt = "Schema:\n" + schemaDescription + "\n\n" +
        "Request:\n" + (naturalLanguage == null ? "" : naturalLanguage.trim()) + "\n\n" +
        "Previous SQL (failed):\n" + (previousSql == null ? "" : previousSql) + "\n\n" +
        "Error:\n" + (errorText == null ? "" : errorText) + "\n\n" +
        "Return ONLY the corrected SQL.";
    try {
      RestTemplate client = new RestTemplate();
      SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
      factory.setConnectTimeout(20000);
      factory.setReadTimeout(120000);
      client.setRequestFactory(factory);

      Map<String, Object> body = new HashMap<>();
      body.put("model", model);
      body.put("stream", false);
      body.put("messages", buildFewShotMessages(systemPrompt, userPrompt));
      String url = baseUrl.endsWith("/") ? baseUrl + "api/chat" : baseUrl + "/api/chat";
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      HttpEntity<String> entity = new HttpEntity<>(objectMapper.writeValueAsString(body), headers);
      ResponseEntity<String> resp = client.exchange(URI.create(url), HttpMethod.POST, entity, String.class);
      if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) {
        throw new RuntimeException("Ollama API error: " + resp.getStatusCode());
      }
      JsonNode root = objectMapper.readTree(resp.getBody());
      String content = root.path("message").path("content").asText("");
      String sql = extractSql(content);
      if (!StringUtils.hasText(sql)) {
        throw new RuntimeException("Empty SQL from model");
      }
      return sql.trim();
    } catch (Exception e) {
      throw new RuntimeException("Failed to call Ollama: " + e.getMessage(), e);
    }
  }

  private List<Map<String, String>> buildFewShotMessages(String systemPrompt, String userPrompt) {
    List<Map<String, String>> messages = new java.util.ArrayList<>();
    messages.add(Map.of("role", "system", "content", systemPrompt));
    messages.add(Map.of("role", "user", "content", "Schema:\n table articles(id int, title varchar)\n\nRequest: list all articles group by title with count\nReturn ONLY the SQL."));
    messages.add(Map.of("role", "assistant", "content", "SELECT title, COUNT(*) AS count FROM articles GROUP BY title ORDER BY count DESC"));
    messages.add(Map.of("role", "user", "content", "Schema:\n table orders(id int, customer_id int, total decimal),\n table customers(id int, name varchar)\n\nRequest: list orders with customer names\nReturn ONLY the SQL."));
    messages.add(Map.of("role", "assistant", "content", "SELECT o.id, c.name, o.total FROM orders o JOIN customers c ON o.customer_id = c.id"));
    messages.add(Map.of("role", "user", "content", userPrompt));
    return messages;
  }
}


