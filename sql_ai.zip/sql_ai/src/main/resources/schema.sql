CREATE TABLE IF NOT EXISTS articles (
  id INT PRIMARY KEY,
  title VARCHAR(255)
);

MERGE INTO articles (id, title) KEY(id) VALUES
  (1, 'Query-GPT Overview'),
  (2, 'LLM-powered SQL'),
  (3, 'Productionizing GPT for Analytics');



