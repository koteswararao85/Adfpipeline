package com.example.uberquerygpt.service;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.stereotype.Service;

@Service
public class SchemaIntrospectionService {

  private final DataSource dataSource;

  public SchemaIntrospectionService(DataSource dataSource) {
    this.dataSource = dataSource;
  }

  public String buildSchemaDescription() {
    return buildSchemaDescription(40, 40);
  }

  public String buildSchemaDescription(int maxTables, int maxColumnsPerTable) {
    List<String> lines = new ArrayList<>();
    try (Connection conn = dataSource.getConnection()) {
      DatabaseMetaData meta = conn.getMetaData();
      try (ResultSet tables = meta.getTables(conn.getCatalog(), null, "%", new String[]{"TABLE"})) {
        int t = 0;
        while (tables.next() && t < maxTables) {
          String schema = tables.getString("TABLE_SCHEM");
          String table = tables.getString("TABLE_NAME");
          String fq = schema != null && !schema.isBlank() ? schema + "." + table : table;

          List<String> cols = new ArrayList<>();
          try (ResultSet columns = meta.getColumns(conn.getCatalog(), schema, table, "%")) {
            int c = 0;
            while (columns.next() && c < maxColumnsPerTable) {
              String name = columns.getString("COLUMN_NAME");
              String type = columns.getString("TYPE_NAME");
              cols.add(name + " " + type);
              c++;
            }
          }
          lines.add("table " + fq + "(" + String.join(", ", cols) + ")");
          t++;
        }
      }
    } catch (Exception e) {
      lines.add("/* schema introspection failed: " + e.getMessage() + " */");
    }
    return String.join("\n", lines);
  }
}



