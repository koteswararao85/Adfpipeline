package com.example.uberquerygpt.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Service;

@Service
public class SqlQueryService {

  private final JdbcTemplate jdbcTemplate;

  public SqlQueryService(JdbcTemplate jdbcTemplate) {
    this.jdbcTemplate = jdbcTemplate;
  }

  public Map<String, Object> runSelect(String sql) {
    String normalized = sql == null ? "" : sql.trim().toLowerCase();
    if (!normalized.startsWith("select")) {
      throw new IllegalArgumentException("Only SELECT statements are allowed");
    }

    Map<String, Object> result = new HashMap<>();
    List<String> columns = new ArrayList<>();
    List<List<Object>> rows = new ArrayList<>();

    try {
      SqlRowSet rs = jdbcTemplate.queryForRowSet(sql);
      int columnCount = rs.getMetaData().getColumnCount();
      for (int i = 1; i <= columnCount; i++) {
        columns.add(rs.getMetaData().getColumnLabel(i));
      }
      while (rs.next()) {
        List<Object> row = new ArrayList<>(columnCount);
        for (int i = 1; i <= columnCount; i++) {
          row.add(rs.getObject(i));
        }
        rows.add(row);
      }
    } catch (DataAccessException ex) {
      throw ex;
    }

    result.put("columns", columns);
    result.put("rows", rows);
    return result;
  }
}



